# Dataset

Pima Indians Diabetes Database (768 rows, 8 features, binary `Outcome`).

Get it with `python src/download_data.py`, or download manually from Kaggle
(https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database) and save
it as `data/diabetes.csv` with the header:
`Pregnancies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction,Age,Outcome`
