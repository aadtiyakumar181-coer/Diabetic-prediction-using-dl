"""Data loading and preprocessing for the Pima Indians Diabetes dataset."""
import os
import urllib.request

import numpy as np
import pandas as pd

URL = ("https://raw.githubusercontent.com/jbrownlee/Datasets/master/"
       "pima-indians-diabetes.data.csv")
COLUMNS = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
           "Insulin", "BMI", "DiabetesPedigreeFunction", "Age", "Outcome"]
# In this dataset a 0 in these columns is a missing value, not a real measurement.
ZERO_AS_MISSING = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "diabetes.csv")


def load_data(path: str = DATA_PATH) -> pd.DataFrame:
    """Load the CSV, downloading it first if it is not present."""
    if not os.path.exists(path):
        print(f"Downloading dataset to {path} ...")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        urllib.request.urlretrieve(URL, path)
    df = pd.read_csv(path)
    # Kaggle version has a header; the raw GitHub version does not.
    if "Outcome" not in df.columns:
        df = pd.read_csv(path, header=None, names=COLUMNS)
    return df


def mark_missing(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df[ZERO_AS_MISSING] = df[ZERO_AS_MISSING].replace(0, np.nan)
    return df
