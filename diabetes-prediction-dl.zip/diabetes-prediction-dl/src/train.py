"""Train a deep neural network (MLP) to predict diabetes.

Run from the project root:  python src/train.py
"""
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.metrics import (ConfusionMatrixDisplay, classification_report,
                             roc_auc_score, roc_curve)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "diabetes.csv"
MODELS = ROOT / "models"
REPORTS = ROOT / "reports"
SEED = 42
# In this dataset a 0 in these columns means "missing", not a real value.
ZERO_AS_MISSING = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]

tf.keras.utils.set_random_seed(SEED)


def load_and_clean():
    df = pd.read_csv(DATA)
    df[ZERO_AS_MISSING] = df[ZERO_AS_MISSING].replace(0, np.nan)
    medians = df[ZERO_AS_MISSING].median()
    df[ZERO_AS_MISSING] = df[ZERO_AS_MISSING].fillna(medians)
    return df, medians


def build_model(n_features):
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(n_features,)),
        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(16, activation="relu"),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(8, activation="relu"),
        tf.keras.layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy", tf.keras.metrics.AUC(name="auc")],
    )
    return model


def main():
    if not DATA.exists():
        raise SystemExit("Dataset missing. Run: python src/download_data.py")

    df, medians = load_and_clean()
    X = df.drop(columns="Outcome")
    y = df["Outcome"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=SEED)

    scaler = StandardScaler().fit(X_train)  # fit on train only: no data leakage
    X_train_s, X_test_s = scaler.transform(X_train), scaler.transform(X_test)

    weights = compute_class_weight("balanced", classes=np.unique(y_train), y=y_train)
    class_weight = {0: weights[0], 1: weights[1]}

    model = build_model(X_train_s.shape[1])
    model.summary()

    callbacks = [
        tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=20,
                                         restore_best_weights=True),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                                             patience=8),
    ]
    history = model.fit(X_train_s, y_train, validation_split=0.2, epochs=300,
                        batch_size=32, class_weight=class_weight,
                        callbacks=callbacks, verbose=2)

    # ---- Evaluation ----
    probs = model.predict(X_test_s).ravel()
    preds = (probs >= 0.5).astype(int)
    print("\n=== Test set results ===")
    print(classification_report(y_test, preds, target_names=["No diabetes", "Diabetes"]))
    print("ROC-AUC:", round(roc_auc_score(y_test, probs), 4))

    # ---- Plots ----
    REPORTS.mkdir(exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].plot(history.history["loss"], label="train")
    ax[0].plot(history.history["val_loss"], label="validation")
    ax[0].set(title="Loss", xlabel="Epoch"); ax[0].legend()
    ax[1].plot(history.history["accuracy"], label="train")
    ax[1].plot(history.history["val_accuracy"], label="validation")
    ax[1].set(title="Accuracy", xlabel="Epoch"); ax[1].legend()
    fig.tight_layout(); fig.savefig(REPORTS / "training_curves.png", dpi=120)

    fig, ax = plt.subplots(figsize=(4.5, 4))
    ConfusionMatrixDisplay.from_predictions(y_test, preds, ax=ax, colorbar=False)
    ax.set_title("Confusion matrix"); fig.tight_layout()
    fig.savefig(REPORTS / "confusion_matrix.png", dpi=120)

    fpr, tpr, _ = roc_curve(y_test, probs)
    fig, ax = plt.subplots(figsize=(4.5, 4))
    ax.plot(fpr, tpr); ax.plot([0, 1], [0, 1], "--", color="gray")
    ax.set(title="ROC curve", xlabel="False positive rate", ylabel="True positive rate")
    fig.tight_layout(); fig.savefig(REPORTS / "roc_curve.png", dpi=120)

    # ---- Save artifacts ----
    MODELS.mkdir(exist_ok=True)
    model.save(MODELS / "diabetes_model.keras")
    joblib.dump({"scaler": scaler, "medians": medians, "columns": list(X.columns)},
                MODELS / "preprocessor.joblib")
    print(f"\nSaved model + preprocessor to {MODELS}, plots to {REPORTS}")


if __name__ == "__main__":
    main()
