# Diabetes Prediction using Deep Learning

A beginner-friendly deep learning project that predicts whether a patient is likely to have
diabetes from 8 diagnostic measurements, using a neural network built with TensorFlow/Keras.

> Educational project only. Not a medical device and not medical advice.

## Pipeline
1. Download the Pima Indians Diabetes dataset
2. Clean data (zeros in Glucose, BloodPressure, SkinThickness, Insulin, BMI = missing, so fill with median)
3. Stratified 80/20 train/test split, then standardize features (fit on train only)
4. Train an MLP (32-16-8-1) with BatchNorm, Dropout, class weights and early stopping
5. Evaluate: precision, recall, F1, ROC-AUC, confusion matrix
6. Save the model and use it for predictions

## Project structure
```
diabetes-prediction-dl/
├── data/            dataset (downloaded, not committed)
├── models/          saved model + preprocessor
├── reports/         training curves, confusion matrix, ROC curve
├── src/
│   ├── download_data.py
│   ├── train.py
│   └── predict.py
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

## How to run
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python src/download_data.py
python src/train.py
python src/predict.py --pregnancies 2 --glucose 140 --bp 80 --skin 30 --insulin 120 --bmi 33.5 --pedigree 0.5 --age 45
```

## Expected results
Roughly 75-80% accuracy and ~0.82-0.85 ROC-AUC on the test set. This is a small dataset, so
results vary a little between runs.

## References
- Dataset (Kaggle): https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database
- Original paper: Smith et al., 1988, "Using the ADAP learning algorithm to forecast the onset of diabetes mellitus"
- TensorFlow/Keras guide: https://www.tensorflow.org/guide/keras
- Keras Sequential model: https://keras.io/guides/sequential_model/
- scikit-learn metrics: https://scikit-learn.org/stable/modules/model_evaluation.html
- GitHub docs, create a repo: https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository

## Future improvements
Compare with Random Forest / XGBoost, add k-fold cross-validation, SHAP explanations, a Streamlit web app.
