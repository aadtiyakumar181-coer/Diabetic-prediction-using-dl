"""Predict diabetes risk for one patient.

Example:
  python src/predict.py --pregnancies 2 --glucose 140 --bp 80 --skin 30 \
      --insulin 120 --bmi 33.5 --pedigree 0.5 --age 45
"""
import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import tensorflow as tf

MODELS = Path(__file__).resolve().parent.parent / "models"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--pregnancies", type=float, required=True)
    p.add_argument("--glucose", type=float, required=True)
    p.add_argument("--bp", type=float, required=True, help="diastolic blood pressure (mm Hg)")
    p.add_argument("--skin", type=float, required=True, help="skin fold thickness (mm)")
    p.add_argument("--insulin", type=float, required=True, help="2-hour serum insulin (mu U/ml)")
    p.add_argument("--bmi", type=float, required=True)
    p.add_argument("--pedigree", type=float, required=True, help="diabetes pedigree function")
    p.add_argument("--age", type=float, required=True)
    a = p.parse_args()

    bundle = joblib.load(MODELS / "preprocessor.joblib")
    model = tf.keras.models.load_model(MODELS / "diabetes_model.keras")

    row = pd.DataFrame([[a.pregnancies, a.glucose, a.bp, a.skin, a.insulin,
                         a.bmi, a.pedigree, a.age]], columns=bundle["columns"])
    for col, med in bundle["medians"].items():   # 0 means missing in this dataset
        row[col] = row[col].replace(0, np.nan).fillna(med)

    prob = float(model.predict(bundle["scaler"].transform(row), verbose=0)[0][0])
    label = "HIGH risk of diabetes" if prob >= 0.5 else "LOW risk of diabetes"
    print(f"Probability: {prob:.2%}  ->  {label}")
    print("Educational demo only. Not medical advice.")


if __name__ == "__main__":
    main()
