"""Download the Pima Indians Diabetes dataset into data/diabetes.csv."""
from pathlib import Path
import urllib.request

import pandas as pd

URL = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/pima-indians-diabetes.data.csv"
COLUMNS = [
    "Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin",
    "BMI", "DiabetesPedigreeFunction", "Age", "Outcome",
]
OUT = Path(__file__).resolve().parent.parent / "data" / "diabetes.csv"


def main():
    OUT.parent.mkdir(exist_ok=True)
    raw = OUT.with_suffix(".tmp")
    urllib.request.urlretrieve(URL, raw)
    df = pd.read_csv(raw, header=None, names=COLUMNS)
    raw.unlink()
    df.to_csv(OUT, index=False)
    print(f"Saved {len(df)} rows to {OUT}")


if __name__ == "__main__":
    main()
